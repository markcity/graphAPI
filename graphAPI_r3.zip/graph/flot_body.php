
	<div id="content">

		<div class="demo-container">
			<div id="placeholder" class="demo-placeholder"></div>
		</div>

		<div class="demo-container">
			<div id="placeholder2" class="demo-placeholder"></div>
		</div>
		

		<p>
			<button class="fetchSeries">First dataset</button>
			[ <a href="data/data-eu-gdp-growth.json">see data</a> ]
			<span></span>
		</p>

		<p>
			<button class="fetchSeries">Second dataset</button>
			[ <a href="data/data-japan-gdp-growth.json">see data</a> ]
			<span></span>
		</p>

		<p>
			<button class="fetchSeries">Third dataset</button>
			[ <a href="data/data-usa-gdp-growth.json">see data</a> ]
			<span></span>
		</p>

		<p>If you combine AJAX with setTimeout, you can poll the server for new data.</p>

		<p>
			<button class="dataUpdate">Poll for data</button>
		</p>
