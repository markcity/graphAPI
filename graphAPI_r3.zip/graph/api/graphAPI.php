<?php
/**  Be strict with types */
declare(strict_types=1);
/**  Show all errors */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

$test='no';

?>

<?php
class graphAPI {
	
	/**
	* everything new below here
	* graphAPI for Karim
	*/
	
	function __construct() 
	{
     

	
		$path = $_SERVER['REQUEST_URI'];
		$paths = explode('/', $path);
		$this->debug_mode=false;
		//http://cservice.uk/graph/api/test/my/graph
		//[3] => test
		//[4] => my
		//[5] => graph

		//https://interestme.co.uk/graph/api/count/visits/all
		//http://cservice.uk/graph/api/count/visits/today	
	
		$this->verb=$paths[3]; //e.g. count/list/read/write/authenticate
		$this->module=$paths[4];//e.g. visits
		$this->range=$paths[5];//all
		
		if (isset($paths[6])){
			$this->debug=$paths[6];//debug
			if ($this->debug=='debug'){
				$this->debug_mode=true;
			}
		}
		//quick check for data
		//$stmt = $pdo->query('SELECT * FROM hits');
		//while ($row = $stmt->fetch())
		//{
			//echo $row['id'] . "\n";
		//	print_r($row);
		//}

		//pdo
	if ($this->debug_mode){
		print "MHIn BaseClass constructor\n";
	}
	
    }
	
	
	
	public function pdo_connect()
	{
		//pdo
		$host = '127.0.0.1';
		$db   = 'graphAPI';
		$user = 'root';
		$pass = 'bc714a46cd342b2b50f16ab0e0c062d4698c0bf48a38c4b5';
		$charset = 'utf8mb4';

		$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
		$opt = [
			PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
			PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
			PDO::ATTR_EMULATE_PREPARES   => false,
		];
		$this->pdo = new PDO($dsn, $user, $pass, $opt);
	}
	
	
	
	public function process_route()
	{
		
		//given a route (verb, module, range)
		//decide which set of functions to use e.g. list, count
				
		switch ($this->verb) {
			case 'list':
				echo "verb equals list";
				break;
			case 'count':
				//echo "verb equals count";
				echo $this->count_query();
				break;
			default: 
				echo "Invalid verb - throw exception or be kinder?";
				break;
		}
		
		
		
		
	}
	
	
	public function count_query(){
		//return ('count_data');
		//prepare SQL
		
		//Select count(value) as visit_count from hits
		
		
		if ($this->module=='visits' && $this->range=='all'){
			$query = 'SELECT count(value) as visit_count from hits LIMIT 1';
			
			$out='';
			
			$stmt = $this->pdo->query($query);
			while ($row = $stmt->fetch())
			{
				//add the returned row to the array 
				$out[]= $row;
			}
			return json_encode($out);
			
		}
		
		if ($this->module=='visits_by_day' && $this->range=='all'){
			$query = 'SELECT count(value) as visit_count from hits LIMIT 1';
			$query='select date(date_created) as date_created,count(value) as hit_count from hits group by date(date_created)';
			
			$out='';
			
			$stmt = $this->pdo->query($query);
			while ($row = $stmt->fetch())
			{
				//add the returned row to the array 
				//$out[]= $row;
				$out[] = array($row['date_created'],$row['hit_count']);
				
				
			}
			return json_encode($out);
			
		}
		
		return 'not found';
	}
	
	
	
	
	/**
	 * ignore below
	 * FizzBuzz.
	 * Class and method that takes 2 integers between 1 and 100 as an array of 2 integers.
	 * Outputs each integer in the inclusive range with conditional labels 
	 * 	- 'Fizz' if integer divisible by 3 
	 *	- 'Buzz' if integer is divisible by 5 
	 *	- 'FizzBuzz' if integer is divisible by 3 and 5 
	 * 	- No label if integer doesn't meet the above criteria
	 */	
	
	
		public function numberWithinValidRange(int $value): bool  
			{
				/** 
				* This function checks whether an integer is within the range specified.
				* The integer must be inclusively in the range 1, 100
				* Function will return true if within range, otherwise cause an exception
				*/
				
				$min=1;
				$max=100;
				
				if (($min <= $value) && ($value <= $max)){
				return true;
					}
					else{
						throw new Exception("$value provided as an input - valid values are integers in the range $min - $max");
					}
				
		   }

		   
		public function createFizzBuzzLabelsForAnInteger(int $valueToTest): string
			{
				
				/** 
				* This function checks whether an integer is divisible by 3 and by 5
				* We will use the modulo function % which gives the remainder after dividing 2 numbers 
				* Will return integer and conditional labels Fizz (divisible 3) and Buzz (divisible 5)
				* modulo
				* $a % $b
				*/
				
				
				/**  We will build a single line for output, starting with the integer supplied	*/
				$out=(string)$valueToTest;  //the original value
				
				/**  If divisible by 3 with no remainder */
				$divisor=3;
				$remainder=($valueToTest % $divisor);
				if ( $remainder == 0 ){ 
				    /**  concatenate the label Fizz to the output line */
					$out=$out." Fizz";
				}
				
				/**  If divisible by 5 with no remainder */
				$divisor=5;
				$remainder=($valueToTest % $divisor);
				if ($remainder == 0){ 
					/**  concatenate the label Fizz to the output line */
					$out=$out." Buzz";
				}
				
				return $out;
				
		   }
		   
					   
		   
				/**  using a PHP 7 feature ... building an array coercively in function parameters */
				
				public function createFizzBuzzLabelsForRange(int ...$numberRange): string
					{
	
						/**
						 * The main FizzBuzz function
						 * takes 2 integers between 1 and 100 as an array.
						 * Outputs each integer in the inclusive range with conditional labels 
						 * 	- 'Fizz' if integer divisible by 3 
						 *	- 'Buzz' if integer is divisible by 5 
						 *	- 'FizzBuzz' if integer is divisible by 3 and 5 
						 * 	- No label if integer doesn't meet the above criteria
						 * Finally returns an HTML string with multiple lines using <br> as the line break markup.
						 */	


	
						/**  Expecting a 2 index array, so throw an exception if 2 values */
						$arraySize=sizeof($numberRange);
						if ($arraySize!=2)
							{
							throw new Exception("An array of size $arraySize was provided as an input - 2 required");
							}
					
						$startNumber=$numberRange[0];
						$endNumber=$numberRange[1];
						
						/**  Initialise the FizzBuzz text for output */
						$fizzBuzzText="";
						
						
						/**  Are the 2 values within the correct range. If not, throw an exception. */
						if (!$this->numberWithinValidRange($startNumber) && !$this->numberWithinValidRange($endNumber))
							{
							throw new Exception("The range values need to be between 1 and 100, $startNumber and $endNumber were provided");
							}					
						
						foreach (range($startNumber,$endNumber) as $currentInteger)
							{
							/**  Add currentInteger and associated labels to the output lines  */	
							$fizzBuzzText=$fizzBuzzText."<br>".$this->createFizzBuzzLabelsForAnInteger($currentInteger);
							}
						
						return $fizzBuzzText;
				
					}
		   
		   
	   }




?>




<?php

class FizzBuzz {
	
	
	/**
	 * FizzBuzz.
	 * Class and method that takes 2 integers between 1 and 100 as an array of 2 integers.
	 * Outputs each integer in the inclusive range with conditional labels 
	 * 	- 'Fizz' if integer divisible by 3 
	 *	- 'Buzz' if integer is divisible by 5 
	 *	- 'FizzBuzz' if integer is divisible by 3 and 5 
	 * 	- No label if integer doesn't meet the above criteria
	 */	
	
	
		public function numberWithinValidRange(int $value): bool  
			{
				/** 
				* This function checks whether an integer is within the range specified.
				* The integer must be inclusively in the range 1, 100
				* Function will return true if within range, otherwise cause an exception
				*/
				
				$min=1;
				$max=100;
				
				if (($min <= $value) && ($value <= $max)){
				return true;
					}
					else{
						throw new Exception("$value provided as an input - valid values are integers in the range $min - $max");
					}
				
		   }

		   
		public function createFizzBuzzLabelsForAnInteger(int $valueToTest): string
			{
				
				/** 
				* This function checks whether an integer is divisible by 3 and by 5
				* We will use the modulo function % which gives the remainder after dividing 2 numbers 
				* Will return integer and conditional labels Fizz (divisible 3) and Buzz (divisible 5)
				* modulo
				* $a % $b
				*/
				
				
				/**  We will build a single line for output, starting with the integer supplied	*/
				$out=(string)$valueToTest;  //the original value
				
				/**  If divisible by 3 with no remainder */
				$divisor=3;
				$remainder=($valueToTest % $divisor);
				if ( $remainder == 0 ){ 
				    /**  concatenate the label Fizz to the output line */
					$out=$out." Fizz";
				}
				
				/**  If divisible by 5 with no remainder */
				$divisor=5;
				$remainder=($valueToTest % $divisor);
				if ($remainder == 0){ 
					/**  concatenate the label Fizz to the output line */
					$out=$out." Buzz";
				}
				
				return $out;
				
		   }
		   
					   
		   
				/**  using a PHP 7 feature ... building an array coercively in function parameters */
				
				public function createFizzBuzzLabelsForRange(int ...$numberRange): string
					{
	
						/**
						 * The main FizzBuzz function
						 * takes 2 integers between 1 and 100 as an array.
						 * Outputs each integer in the inclusive range with conditional labels 
						 * 	- 'Fizz' if integer divisible by 3 
						 *	- 'Buzz' if integer is divisible by 5 
						 *	- 'FizzBuzz' if integer is divisible by 3 and 5 
						 * 	- No label if integer doesn't meet the above criteria
						 * Finally returns an HTML string with multiple lines using <br> as the line break markup.
						 */	


	
						/**  Expecting a 2 index array, so throw an exception if 2 values */
						$arraySize=sizeof($numberRange);
						if ($arraySize!=2)
							{
							throw new Exception("An array of size $arraySize was provided as an input - 2 required");
							}
					
						$startNumber=$numberRange[0];
						$endNumber=$numberRange[1];
						
						/**  Initialise the FizzBuzz text for output */
						$fizzBuzzText="";
						
						
						/**  Are the 2 values within the correct range. If not, throw an exception. */
						if (!$this->numberWithinValidRange($startNumber) && !$this->numberWithinValidRange($endNumber))
							{
							throw new Exception("The range values need to be between 1 and 100, $startNumber and $endNumber were provided");
							}					
						
						foreach (range($startNumber,$endNumber) as $currentInteger)
							{
							/**  Add currentInteger and associated labels to the output lines  */	
							$fizzBuzzText=$fizzBuzzText."<br>".$this->createFizzBuzzLabelsForAnInteger($currentInteger);
							}
						
						return $fizzBuzzText;
				
					}
		   
		   
	   }
	
if ($test=='yes'){

/**  Tests for range and type */
echo "<hr>";
$check_values = new FizzBuzz;
echo "<h1>Tests</h1>";

echo "<hr>";
if ($check_values->numberWithinValidRange(1)){
	echo "Tested numberWithinValidRange with 1 - successfully";
}
echo "<br>check numberWithinValidRange 1 | ".$check_values->numberWithinValidRange(1);
echo "<br>check numberWithinValidRange 76 | ".$check_values->numberWithinValidRange(76);
echo "<br>check numberWithinValidRange 100 | ".$check_values->numberWithinValidRange(100);

#echo "<br>check numberWithinValidRange 0 | ".$check_values->numberWithinValidRange(0);
echo "<br>Testing with 0 as value gives exception: Fatal error: Uncaught Exception: 0 provided as an input - valid values are integers in the range 1 - 100 in /var/www/html_interestme/di/index_test2.php:116 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(202): FizzBuzz->numberWithinValidRange(0) #1 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 116";

#echo "<br>check numberWithinValidRange 101 | ".$check_values->numberWithinValidRange(101);
echo "<br>Testing with 101 as value gives exception: Fatal error: Uncaught Exception: 101 provided as an input - valid values are integers in the range 1 - 100 in /var/www/html_interestme/di/index_test2.php:116 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(202): FizzBuzz->numberWithinValidRange(101) #1 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 116";


echo "<br>checking with text gives error - Fatal error: Uncaught TypeError: Argument 1 passed to FizzBuzz::numberWithinValidRange() must be of the type integer, string given, called in /var/www/html_interestme/di/index_test2.php on line 173 and defined in /var/www/html_interestme/di/index_test2.php:79 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(173): FizzBuzz->numberWithinValidRange('text') #1 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 79";
#echo "<br>check numberWithinValidRange text ".$check_values->numberWithinValidRange('text');
echo "<br>expecting 3 passes";

/** testing fizzbuzz */
echo "<hr>";
echo "<br>expecting 1 fizz, 1 buzz and a fizzbuzz passes";
echo "<br>check createFizzBuzzLabelsForAnInteger 1 | ".$check_values->createFizzBuzzLabelsForAnInteger(1);
echo "<br>check createFizzBuzzLabelsForAnInteger 3 | ".$check_values->createFizzBuzzLabelsForAnInteger(3);
echo "<br>check createFizzBuzzLabelsForAnInteger 5 | ".$check_values->createFizzBuzzLabelsForAnInteger(5);
echo "<br>check createFizzBuzzLabelsForAnInteger 15 | ".$check_values->createFizzBuzzLabelsForAnInteger(15);

/** testing fizzbuzz range */
echo "<hr>";
echo "<br>checking the ranges now";
echo "<br>check fizzbuzz_range 2-3 | ".$check_values->createFizzBuzzLabelsForRange(2,3);
echo "<br>checking with array with text gives fatal error: Fatal error: Uncaught TypeError: Argument 1 passed to FizzBuzz::inrange() must be of the type integer, string given, called in /var/www/html_interestme/di/index_test2.php on line 120 and defined in /var/www/html_interestme/di/index_test2.php:79 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(120): FizzBuzz->inrange('2') #1 /var/www/html_interestme/di/index_test2.php(188): FizzBuzz->fizzbuzz_range(Array) #2 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 79";
#echo "<br>check fizzbuzz_range 2-3 | ".$check_values->fizzbuzz_range(101);
echo "<br>checking with non array input gives fatal error: Fatal error: Uncaught TypeError: Argument 1 passed to FizzBuzz::fizzbuzz_range() must be of the type array, integer given, called in /var/www/html_interestme/di/index_test2.php on line 190 and defined in /var/www/html_interestme/di/index_test2.php:113 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(190): FizzBuzz->fizzbuzz_range(101) #1 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 113";
echo "<br>check fizzbuzz_range 15-15 | ".$check_values->createFizzBuzzLabelsForRange(15,15);
echo "<br>check fizzbuzz_range 1-100 | ".$check_values->createFizzBuzzLabelsForRange(1,100);
#echo "<br>check fizzbuzz_range 101-102 | ".$check_values->createFizzBuzzLabelsForRange(101,102);
echo "<br>testing FizzBuzz for range 101,102 is Fatal error: Uncaught Exception: 101 provided as an input - valid values are integers in the range 1 - 100 in /var/www/html_interestme/di/index_test2.php:105 Stack trace: #0 /var/www/html_interestme/di/index_test2.php(167): FizzBuzz->numberWithinValidRange(101) #1 /var/www/html_interestme/di/index_test2.php(229): FizzBuzz->createFizzBuzzLabelsForRange(101, 102) #2 {main} thrown in /var/www/html_interestme/di/index_test2.php on line 105";

echo "<hr>";
echo "<h3>Final Call</h3>";
echo "<hr>";
/**  final test - passing integers directly into function */

echo "<br>FizzBuzz range a with range 90-95 | ".$check_values->createFizzBuzzLabelsForRange(90,95);

echo "<hr>";
echo "Mark Hopgood";

?>
<pre>
Development Task
Business requirements
Write a class with a method that takes 2 integers between 1 and 100.
Loop from the first integer to the second integer.
Write out each integer.
If the integer is divisible by 3 also print out “fizz”
If the integer is divisible by 5 also print out “buzz”
Development requirements
Before you write any other code write some unit tests
As we are developing Enterprise Software we will paying particular attention to:
1. Code clarity and ease of understating
2. Well commented code that gives clear and appropriate explanations
3. Code that shows an understanding of Enterprise Software development requirements. i.e. we are
just as interested in failure modes as in the happy path.
4. Code should demonstrate understanding of the features of PHP 7.


Tests: 
expecting inputs 
type integer
between 1 and 100
first to second implies first is smaller or equal to second
loop from first to second
	if divisible 3
	if divisible 5
	
values: type, range
tests: loop
tests: specific values 3, 5, 15 (covers fizz, buzz, fizzbuzz)
tests: range

visible at
https://interestme.co.uk/di/index_test2.php
</pre>
<?php

}
