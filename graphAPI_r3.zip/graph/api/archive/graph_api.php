<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<pre>
Development Task
Business requirements
Write a class with a method that takes 2 integers between 1 and 100.
Loop from the first integer to the second integer.
Write out each integer.
If the integer is divisible by 3 also print out “fizz”
If the integer is divisible by 5 also print out “buzz”
Development requirements
Before you write any other code write some unit tests
As we are developing Enterprise Software we will paying particular attention to:
1. Code clarity and ease of understating
2. Well commented code that gives clear and appropriate explanations
3. Code that shows an understanding of Enterprise Software development requirements. i.e. we are
just as interested in failure modes as in the happy path.
4. Code should demonstrate understanding of the features of PHP 7.

foreach (range(0, 12) as $number) {
    echo $number;
}

consider http://php.net/manual/en/migration70.new-features.php";

Tests: 
expecting inputs 
type integer
between 1 and 100
first to second implies first is smaller or equal to second
loop from first to second
	if divisible 3
	if divisible 5
	
values: type, range
tests: loop
tests: specific values 3, 5, 15 (covers fizz, buzz, fizzbuzz)
tests: range

errors out of bounds, type, a value
</pre>


<?php


echo "<hr>";

class FizzBuzz {
	
	
		public function inrange($value)  //true or false - the input is between the min and max values
			{
				$min=1;
				$max=100;
				$answer=false;
				if (($min <= $value) && ($value <= $max)){
					$answer= true;
					}
				return $answer;
		   }

		   
		   public function fizzbuzz_integer(int $value){
				
				#modulo
				#$a % $b
				$out=$value;  //the original value
				
				$test=3;
				if ($value % $test == 0){ // if divisible by 3, add fizz to output
					$out=$out."fizz";
				}
				
				$test=5;
				if ($value % $test == 0){ // if divisible by 5, add fizz to output
					$out=$out."buzz";
				}
				
				return $out;
				
		   }
		   
		   
		   
				public function fizzbuzz_range($value){
				
					$out="";
					#expect 2 values
					$start=$value[0];
					$end=$value[1];
					$out="prep for fail condition - out of range";
					if ($this->inrange($start) && $this->inrange($end)){
						$out="";
										
						foreach (range($start,$end) as $num)
							{
							$out=$out."<br>".$this->fizzbuzz_integer($num);
							}
					
						
					}
					return $out;
				}
		   
		   #using a PHP 7 feature
				public function fizzbuzz_range_a(int ...$value){
				
					$out="d";
					#expect 2 values
					$start=$value[0];
					$end=$value[1];
					#echo "prep stuff $start $end";
					$out="prep for fail";
					if ($this->inrange($start) && $this->inrange($end)){
						$out="";
										
						foreach (range($start,$end) as $num)
							{
							$out=$out."<br>".$this->fizzbuzz_integer($num);
							}
						return $out;
						
					}
				
				}
		   
		   
		   
		   
	   }
	

if ($test=='yesy'){
#tests for range and type


$check_values = new FizzBuzz;
echo "<h1>Tests</h1>";
#testing ranges
echo "<hr>";
echo "<br>check inrange 1 | ".$check_values->inrange(1);
echo "<br>check inrange 100 | ".$check_values->inrange(100);
echo "<br>check inrange 0 | ".$check_values->inrange(0);
echo "<br>check inrange 101 | ".$check_values->inrange(101);
echo "<br>check inrange text ".$check_values->inrange('text');
echo "<br>expecting 2 passes";

#testing fizzbuzz
echo "<hr>";
echo "<br>expecting 1 fizz, 1 buzz and a fizzbuzz passes";
echo "<br>check fizzbuzz_integer 1 | ".$check_values->fizzbuzz_integer(1);
echo "<br>check fizzbuzz_integer 3 | ".$check_values->fizzbuzz_integer(3);
echo "<br>check fizzbuzz_integer 5 | ".$check_values->fizzbuzz_integer(5);
echo "<br>check fizzbuzz_integer 15 | ".$check_values->fizzbuzz_integer(15);

#testing fizzbuzz range
echo "<hr>";
echo "<br>checking the ranges now";
echo "<br>check fizzbuzz_range 2-3 | ".$check_values->fizzbuzz_range(array(2,3));
echo "<br>check fizzbuzz_range 15-15 | ".$check_values->fizzbuzz_range(array(15,15));
#echo "<br>check fizzbuzz_range 1-100 | ".$check_values->fizzbuzz_range(array(1,100));
echo "<br>check fizzbuzz_range 101-102 | ".$check_values->fizzbuzz_range(array(101,102));

echo "<hr>";
echo "<h3>Final Call</h3>";
echo "<hr>";
#another test - passing array directly into function
echo "<br>FizzBuzz range a with range 90-95 | ".$check_values->fizzbuzz_range_a(90,95);

echo "<hr>";
echo "Mark Hopgood";
}
