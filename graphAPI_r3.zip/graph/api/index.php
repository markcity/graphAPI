<?php
//https://interestme.co.uk/graph/api/count/visits/all
//https://interestme.co.uk/graph/api/count/visits/all/debug
include('graphAPI.php');

$graphData = new graphAPI;
$graphData->pdo_connect();
$graphData->process_route();


//extra debug info
if ($graphData->debug_mode){
echo '<hr>';
echo $graphData->verb;
echo '<hr>';

$stmt = $graphData->pdo->query('SELECT * FROM hits');
		while ($row = $stmt->fetch())
		{
			echo $row['id'] . "\n";
			print_r($row);
		}

		
$path = $_SERVER['REQUEST_URI'];
$paths = explode('/', $path);

//http://cservice.uk/graph/api/test/my/graph
	//[3] => test
    //[4] => my
    //[5] => graph

	
//http://cservice.uk/graph/api/read/visits/today	
	
$verb=$paths[3]; //e.g. read/write/authenticate
$module=$paths[4];//e.g. visits
$range=$paths[5];
	
	
	
// Add some logic for showing the page you need. Maybe remove domain before processing
echo "<pre>";
print_r ($paths);
echo "</pre>";		
		
		
}		
		






