-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 11, 2018 at 01:41 PM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `graphAPI`
--

-- --------------------------------------------------------

--
-- Table structure for table `hits`
--

CREATE TABLE `hits` (
  `id` varchar(36) NOT NULL,
  `date_created` datetime NOT NULL,
  `client_id` varchar(36) NOT NULL,
  `value` varchar(36) NOT NULL,
  `type` varchar(7) NOT NULL,
  `resource_id` varchar(36) NOT NULL,
  `resource_type` varchar(12) NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `gigya_id` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hits`
--

INSERT INTO `hits` (`id`, `date_created`, `client_id`, `value`, `type`, `resource_id`, `resource_type`, `ip_address`, `gigya_id`) VALUES
('24ae9e4c-6c9a-11e8-935f-32faa7bc44ba', '2018-06-04 09:10:00', '2', '1', 'Visit', '2', 'Listing', '192.168.0.2', '0'),
('33d65ad5-6c9a-11e8-935f-32faa7bc44ba', '2018-06-04 09:15:00', '2', '1', 'Visit', '2', 'Listing', '192.168.0.3', '0'),
('c85de69b-6c99-11e8-935f-32faa7bc44ba', '2018-06-01 00:00:00', '1', '1', 'Visit', '1', 'Listing', '192.168.0.1', '0'),
('d9ea82ac-6d6f-11e8-935f-32faa7bc44ba', '2018-06-02 08:10:00', '1', '1', 'Visit', '1', 'Listing', '192.168.0.3', '0'),
('e4a45801-6d6f-11e8-935f-32faa7bc44ba', '2018-06-03 08:10:00', '1', '1', 'Visit', '1', 'Listing', '192.168.0.4', '0'),
('e808c0f9-6c99-11e8-935f-32faa7bc44ba', '2018-06-01 00:05:00', '1', '1', 'Visit', '1', 'Listing', '192.168.0.1', '0'),
('fc3fb05f-6c99-11e8-935f-32faa7bc44ba', '2018-06-01 00:10:00', '1', '1', 'Visit', '1', 'Listing', '192.168.0.1', '0');

--
-- Triggers `hits`
--
DELIMITER $$
CREATE TRIGGER `uuid_for_id` BEFORE INSERT ON `hits` FOR EACH ROW SET NEW.id = UUID()
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hits`
--
ALTER TABLE `hits`
  ADD PRIMARY KEY (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
