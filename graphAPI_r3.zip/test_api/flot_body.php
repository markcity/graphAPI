<div id="content">
	<div class="demo-container">
		<div id="placeholder2" class="demo-placeholder"></div>
	</div>
</div>